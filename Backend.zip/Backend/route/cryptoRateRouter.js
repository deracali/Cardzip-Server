import express from 'express';
import {
    bulkUpdateRates,
    createRate,
    deleteRate,
    getAllRates,
    getRateBySymbol,
    updateRate
} from '../controller/cryptoRateController.js';

const CryptoRateRouter = express.Router();

CryptoRateRouter.get('/get', getAllRates);
CryptoRateRouter.get('/get/:symbol', getRateBySymbol);
CryptoRateRouter.post('/create', createRate);
CryptoRateRouter.put('/update/:symbol', updateRate);
CryptoRateRouter.delete('/delete/:symbol', deleteRate);
CryptoRateRouter.put('/update-bulk', bulkUpdateRates);

export default CryptoRateRouter;
