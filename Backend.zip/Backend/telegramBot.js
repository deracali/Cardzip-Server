import axios from 'axios';
import dotenv from 'dotenv';
import TelegramBot from 'node-telegram-bot-api';

dotenv.config();
const token = process.env.TELEGRAM_BOT_TOKEN;
if (!token) throw new Error('❌ TELEGRAM_BOT_TOKEN missing');

const bot = new TelegramBot(token, { polling: true });
const sessions = new Map();

bot.on('message', async (msg) => {
  const chatId = msg.chat.id.toString();
  const text = msg.text?.trim();
  const photo = msg.photo;

  if (!sessions.has(chatId)) {
    sessions.set(chatId, { step: 1, data: {} });
    return bot.sendMessage(chatId, '🛍️ What gift card are you trading?');
  }
  const session = sessions.get(chatId);

  switch (session.step) {
    case 1: // Card type
      session.data.type = text;
      session.step = 2;
      return bot.sendMessage(chatId, '💱 Currency (e.g. USD):');

    case 2: // Amount
      session.data.currency = text.toUpperCase();
      session.step = 3;
      return bot.sendMessage(chatId, '💰 Amount (number only):');

    case 3: { // Calculate NGN + prompt card number
      session.data.amount = Number(text);
      try {
        const { data } = await axios.get('https://trader-pmqb.onrender.com/api/cards/get');
        const card = data.data.find(c => c.name.toLowerCase() === session.data.type.toLowerCase());
        if (!card) return bot.sendMessage(chatId, '❌ Card not found.');
        const rateEntry = card.types.find(t => t.currency === session.data.currency);
        if (!rateEntry) return bot.sendMessage(chatId, '❌ No rate for that currency.');

        session.data.exchangeRate = rateEntry.rate;
        session.data.ngnAmount = session.data.amount * rateEntry.rate;

        await bot.sendMessage(
          chatId,
          `💱 1 ${session.data.currency} = ₦${rateEntry.rate}\n` +
          `💵 You get ≈ ₦${session.data.ngnAmount.toLocaleString()}`
        );
        session.step = 4;
        return bot.sendMessage(chatId, '🔢 Enter the card number:');
      } catch (e) {
        console.error(e);
        return bot.sendMessage(chatId, '❌ Could not fetch card rate.');
      }
    }

    case 4: // Card number
      session.data.cardNumber = text;
      session.step = 5;
      return bot.sendMessage(chatId, '🖼️ Send the card image as photo:');

    case 5: // Image
      if (!photo) return bot.sendMessage(chatId, '❗ Please send the image now.');
      try {
        const file = await bot.getFile(photo.pop().file_id);
        session.data.imageUrl = `https://api.telegram.org/file/bot${token}/${file.file_path}`;
      } catch (e) {
        console.error(e);
      }
      session.step = 6;
      return bot.sendMessage(chatId, '📝 Add a description? (or type "skip")');

    case 6: // Description
      if (text.toLowerCase() !== 'skip') session.data.userDescription = text;
      session.step = 7;
      return bot.sendMessage(chatId, '💳 Choose payment: USDT, BTC or Bank Transfer');

    case 7: { // Payment method & crypto payout
      const choice = text.toLowerCase();
      if (choice === 'usdt' || choice === 'btc') {
        session.data.paymentMethod = choice.toUpperCase();
        session.step = 8;

        // fetch crypto‑NGN rate
        try {
          const { data: rates } = await axios.get('http://localhost:5000/api/crypto-rate/get');
          const rateObj = rates.find(r => r.symbol === session.data.paymentMethod);
          if (rateObj) {
            // compute crypto amount
            session.data.cryptoPayout =
              session.data.ngnAmount / rateObj.rateInNGN;
            await bot.sendMessage(
              chatId,
              `💸 ₦${session.data.ngnAmount.toLocaleString()} ≈ ` +
              `${session.data.cryptoPayout.toFixed(8)} ${rateObj.symbol}`
            );
          }
        } catch (e) {
          console.error(e);
          await bot.sendMessage(chatId, '⚠️ Could not fetch crypto rate.');
        }
        return bot.sendMessage(
          chatId,
          `📩 Enter your ${session.data.paymentMethod} wallet address:`
        );
      }
      if (choice === 'bank transfer' || choice === 'bank') {
        session.data.paymentMethod = 'BANK';
        session.step = 11;
        return bot.sendMessage(chatId, '🏦 Enter your bank name:');
      }
      return bot.sendMessage(chatId, '❗ Invalid. Type USDT, BTC or Bank');
    }

    case 8: { // Validate wallet & submit
      const addr = text;
      const isBTC = session.data.paymentMethod === 'BTC';
      const isUSDT = session.data.paymentMethod === 'USDT';
      const btcRegex = /^[13][a-km-zA-HJ-NP-Z1-9]{25,34}$/;
      const usdtRegex = /^T[a-zA-Z0-9]{33}$/;

      if ((isBTC && !btcRegex.test(addr)) ||
          (isUSDT && !usdtRegex.test(addr))) {
        return bot.sendMessage(
          chatId,
          `❌ Invalid ${session.data.paymentMethod} address. Try again:`
        );
      }

      session.data.walletAddress = addr;
      // Submit
      try {
        const payload = {
          ...session.data,
          status: 'pending',
          cryptoPayout: session.data.cryptoPayout
        };
        await axios.post('http://localhost:5000/api/gift-cards/create', payload);
        await bot.sendMessage(
          chatId,
          `✅ Submitted!\nYou’ll receive ${session.data.cryptoPayout.toFixed(8)} ` +
          `${session.data.paymentMethod}`
        );
      } catch (e) {
        console.error(e);
        await bot.sendMessage(chatId, '❌ Submission failed.');
      }
      sessions.delete(chatId);
      break;
    }

    // BANK FLOW
    case 11:
      session.data.bankName = text;
      session.step = 12;
      return bot.sendMessage(chatId, '🏛️ Enter your account number:');

    case 12:
      session.data.accountNumber = text;
      session.step = 13;
      return bot.sendMessage(chatId, '👤 Enter your account name:');

    case 13:
      session.data.accountName = text;
      try {
        const payload = { ...session.data, status: 'pending' };
        await axios.post('http://localhost:5000/api/gift-cards/create', payload);
        await bot.sendMessage(chatId, '✅ Submitted for review!');
      } catch (e) {
        console.error(e);
        await bot.sendMessage(chatId, '❌ Submission failed.');
      }
      sessions.delete(chatId);
      break;

    default:
      return bot.sendMessage(chatId, '❓ Type anything to restart');
  }
});

export default bot;
